package com.example.storyappnadhira.model

data class User(
    val userId: String,
    val name: String,
    val token: String,
)