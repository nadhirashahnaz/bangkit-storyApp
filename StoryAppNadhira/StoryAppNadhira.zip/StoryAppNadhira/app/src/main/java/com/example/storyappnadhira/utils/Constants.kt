package com.example.storyappnadhira.utils

object Constants {
    const val CAMERA_X_RESULT = 200
    const val FILENAME_FORMAT = "dd-MMM-yyyy"
    const val MAXIMAL_SIZE = 1000000
}